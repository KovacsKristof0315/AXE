﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.IO;
using System.Collections;
using System.Reflection;

namespace Compiler
{
    class Function_Class
    {
        public string Type { get; set; }
        public string Name { get; set; }
        public string Parameter { get; set; }

        public Function_Class(string item)
        {
            string[] Splited_Array = item.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            Type = Splited_Array[1];
            Name = Splited_Array[2];
            Parameter = Splited_Array[3];
        }
    }
    class Variable
    {
        public string Type { get; set; }
        public string Name { get; set; }
        public string Value { get; set; }

        public Variable(string item)
        {
            string[] Splited_Array = item.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            Type = Splited_Array[0];
            Name = Splited_Array[1];
            if (Splited_Array.Length >= 3)
            {
                string[] Helper_Array = item.Split('=');
                Value = Helper_Array[1];
            }
        }
    }
    class Program
    {
        //List for key words
        static List<string> KeyWords = new List<string>();

        //List of function names (useless at the moment)
        static List<Function_Class> Functions = new List<Function_Class>();

        //List for variables
        static List<Variable> Variables = new List<Variable>();

        //List for operators
        static List<string> Operators = new List<string>();

        //write function
        static void Write_Function(string Line)
        {
            string[] Splited_Array = Line.Split('(');
            string Output = "";
            Output = Splited_Array[1];
            Output = Output.Remove(0, 1);
            Output = Output.Remove(Output.Length - 2);

            if (Line.Contains("\" +"))
            {
                string[] Variable_Helper_Array = Output.Split('+');
                Output = "";
                for (int i = 0; i < Variable_Helper_Array.Length; i++)
                {
                    if (i % 2 != 0)
                    {
                        var Helper = Variables.Where(x => x.Name == Variable_Helper_Array[i].Trim()).First();
                        Output += Helper.Value;
                    }

                    else
                    {
                        Variable_Helper_Array[i] = Variable_Helper_Array[i].Trim();
                        Variable_Helper_Array[i] = Variable_Helper_Array[i].Replace("\"", string.Empty);
                        Output += Variable_Helper_Array[i];
                    }
                }
                Console.WriteLine(Output);
            }
            else
            {
                Console.WriteLine(Output);

            }
        }

        //Math operations for the variables
        static void Operation(Variable Variable, string Line)
        {
            char OperationType = ' ';
            if (Line.Contains('+'))
            {
                OperationType = '+';
            }
            if (Line.Contains('-'))
            {
                OperationType = '-';
            }
            if (Line.Contains('/'))
            {
                OperationType = '/';
            }
            if (Line.Contains('*'))
            {
                OperationType = '*';
            }

            string[] Splited_At_Equal_Sign = Line.Split('=');

            string[] Splited_Array_At_Operator_Type = Splited_At_Equal_Sign[1].Split(OperationType);

            string VariableName = Splited_Array_At_Operator_Type[0].Trim();

            Splited_Array_At_Operator_Type[1] = Splited_Array_At_Operator_Type[1].Trim();

            bool VariableExists = false;
            foreach (var item in Variables)
            {
                if (item.Name == VariableName)
                {
                    VariableExists = true;
                }
            }
            if (VariableExists)
            {
                var Variable_To_Change = Variables.Where(x => x.Name == VariableName).First();
                if (OperationType == '+')
                {
                    Variable_To_Change.Value = " " + (int.Parse(Variable_To_Change.Value) + int.Parse(Splited_Array_At_Operator_Type[1])).ToString();
                }
                if (OperationType == '-')
                {
                    Variable_To_Change.Value = " " + (int.Parse(Variable_To_Change.Value) - int.Parse(Splited_Array_At_Operator_Type[1])).ToString();
                }
                if (OperationType == '/')
                {
                    Variable_To_Change.Value = " " + (int.Parse(Variable_To_Change.Value) / int.Parse(Splited_Array_At_Operator_Type[1])).ToString();
                }
                if (OperationType == '*')
                {
                    Variable_To_Change.Value = " " + (int.Parse(Variable_To_Change.Value) * int.Parse(Splited_Array_At_Operator_Type[1])).ToString();
                }
                Variable.Value = Variable_To_Change.Value;
            }

        }

        //Handling conditions
        static int Condition_Function(string[] Lines, int CurrLine)
        {
            int i = CurrLine;

            string Line = Lines[CurrLine];
            string Condition = Line.Remove(0, 5);
            Condition = Condition.Remove(Condition.Length - 1);

            string[] Condition_Parts = Condition.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            Variable Helper_Variable;

            if (Condition_Parts[1] == "==")
            {
                Helper_Variable = Variables.Where(x => x.Name == Condition_Parts[0] || x.Name == Condition_Parts[2]).First();
                if (Helper_Variable.Value.Trim() == Condition_Parts[2] || Helper_Variable.Value.Trim() == Condition_Parts[0])
                {
                    i = CurrLine;

                }
                else
                {
                    i = End_Line_Finder(Lines, CurrLine);
                }
            }


            if (Condition_Parts[1] == "<=")
            {
                Helper_Variable = Variables.Where(x => x.Name == Condition_Parts[0] || x.Name == Condition_Parts[2]).First();
                int Value_In_Condition;
                if (int.TryParse(Condition_Parts[0].Trim(), out Value_In_Condition))
                {
                    if (Value_In_Condition <= int.Parse(Helper_Variable.Value.Trim()))
                    {
                        i = CurrLine;
                    }
                    else
                    {
                        i = End_Line_Finder(Lines, CurrLine);
                    }
                }
                if (int.TryParse(Condition_Parts[2].Trim(), out Value_In_Condition))
                {
                    if (int.Parse(Helper_Variable.Value.Trim()) <= Value_In_Condition)
                    {
                        i = CurrLine;
                    }
                    else
                    {
                        i = End_Line_Finder(Lines, CurrLine);
                    }
                }
            }


            if (Condition_Parts[1] == ">=")
            {
                Helper_Variable = Variables.Where(x => x.Name == Condition_Parts[0] || x.Name == Condition_Parts[2]).First();
                int Value_In_Condition;
                if (int.TryParse(Condition_Parts[0].Trim(), out Value_In_Condition))
                {
                    if (Value_In_Condition >= int.Parse(Helper_Variable.Value.Trim()))
                    {
                        i = CurrLine;
                    }
                    else
                    {
                        i = End_Line_Finder(Lines, CurrLine);
                    }
                }
                if (int.TryParse(Condition_Parts[2].Trim(), out Value_In_Condition))
                {
                    if (int.Parse(Helper_Variable.Value.Trim()) >= Value_In_Condition)
                    {
                        i = CurrLine;
                    }
                    else
                    {
                        i = End_Line_Finder(Lines, CurrLine);
                    }
                }
            }


            if (Condition_Parts[1] == ">")
            {
                Helper_Variable = Variables.Where(x => x.Name == Condition_Parts[0] || x.Name == Condition_Parts[2]).First();
                int Value_In_Condition;
                if (int.TryParse(Condition_Parts[0].Trim(), out Value_In_Condition))
                {
                    if (Value_In_Condition > int.Parse(Helper_Variable.Value.Trim()))
                    {
                        i = CurrLine;
                    }
                    else
                    {
                        i = End_Line_Finder(Lines, CurrLine);
                    }
                }
                if (int.TryParse(Condition_Parts[2].Trim(), out Value_In_Condition))
                {
                    if (int.Parse(Helper_Variable.Value.Trim()) > Value_In_Condition)
                    {
                        i = CurrLine;
                    }
                    else
                    {
                        i = End_Line_Finder(Lines, CurrLine);
                    }
                }
            }


            if (Condition_Parts[1] == "<")
            {
                Helper_Variable = Variables.Where(x => x.Name == Condition_Parts[0] || x.Name == Condition_Parts[2]).First();
                int Value_In_Condition;
                if (int.TryParse(Condition_Parts[0].Trim(), out Value_In_Condition))
                {
                    if (Value_In_Condition < int.Parse(Helper_Variable.Value.Trim()))
                    {
                        i = CurrLine;
                    }
                    else
                    {
                        i = End_Line_Finder(Lines, CurrLine);
                    }
                }
                if (int.TryParse(Condition_Parts[2].Trim(), out Value_In_Condition))
                {
                    if (int.Parse(Helper_Variable.Value.Trim()) < Value_In_Condition)
                    {
                        i = CurrLine;
                    }
                    else
                    {
                        i = End_Line_Finder(Lines, CurrLine);
                    }
                }
            }


            if (Condition_Parts[1] == "!=")
            {
                Helper_Variable = Variables.Where(x => x.Name == Condition_Parts[0] || x.Name == Condition_Parts[2]).First();
                int Value_In_Condition;
                if (int.TryParse(Condition_Parts[0].Trim(), out Value_In_Condition))
                {
                    if (Value_In_Condition != int.Parse(Helper_Variable.Value.Trim()))
                    {
                        i = CurrLine;
                    }
                    else
                    {
                        i = End_Line_Finder(Lines, CurrLine);
                    }
                }
                if (int.TryParse(Condition_Parts[2].Trim(), out Value_In_Condition))
                {
                    if (int.Parse(Helper_Variable.Value.Trim()) != Value_In_Condition)
                    {
                        i = CurrLine;
                    }
                    else
                    {
                        i = End_Line_Finder(Lines, CurrLine);
                    }
                }
            }


            return i;
        }

        //Handling else
        static int Else_Condition(string[] Lines, string Latest_Condition, int CurrLine)
        {
            int i = CurrLine;

            string Condition = Latest_Condition.Remove(0, 5);
            Condition = Condition.Remove(Condition.Length - 1);


            string[] Condition_Parts = Condition.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            Variable Helper;
            if (Condition_Parts[1] == "==")
            {
                Helper = Variables.Where(x => x.Name == Condition_Parts[0] || x.Name == Condition_Parts[2]).First();
                if (Helper.Value.Trim() != Condition_Parts[2] && Helper.Value.Trim() != Condition_Parts[0])
                {
                    i = CurrLine;
                }
                else
                {
                    i = End_Line_Finder(Lines, CurrLine);
                }
            }


            if (Condition_Parts[1] == "!=")
            {
                Helper = Variables.Where(x => x.Name == Condition_Parts[0] || x.Name == Condition_Parts[2]).First();
                int Value_In_Condition;
                if (int.TryParse(Condition_Parts[0].Trim(), out Value_In_Condition))
                {
                    if (Value_In_Condition == int.Parse(Helper.Value.Trim()))
                    {
                        i = CurrLine;
                    }
                    else
                    {
                        i = End_Line_Finder(Lines, CurrLine);
                    }
                }
                if (int.TryParse(Condition_Parts[2].Trim(), out Value_In_Condition))
                {
                    if (int.Parse(Helper.Value.Trim()) == Value_In_Condition)
                    {
                        i = CurrLine;
                    }
                    else
                    {
                        i = End_Line_Finder(Lines, CurrLine);
                    }
                }
            }


            if (Condition_Parts[1] == "<=")
            {
                Helper = Variables.Where(x => x.Name == Condition_Parts[0] || x.Name == Condition_Parts[2]).First();
                int Value_In_Condition;
                if (int.TryParse(Condition_Parts[0].Trim(), out Value_In_Condition))
                {
                    if (Value_In_Condition > int.Parse(Helper.Value.Trim()))
                    {
                        i = CurrLine;
                    }
                    else
                    {
                        i = End_Line_Finder(Lines, CurrLine);
                    }
                }
                if (int.TryParse(Condition_Parts[2].Trim(), out Value_In_Condition))
                {
                    if (int.Parse(Helper.Value.Trim()) > Value_In_Condition)
                    {
                        i = CurrLine;
                    }
                    else
                    {
                        i = End_Line_Finder(Lines, CurrLine);
                    }
                }
            }


            if (Condition_Parts[1] == ">=")
            {
                Helper = Variables.Where(x => x.Name == Condition_Parts[0] || x.Name == Condition_Parts[2]).First();
                int Value_In_Condition;
                if (int.TryParse(Condition_Parts[0].Trim(), out Value_In_Condition))
                {
                    if (Value_In_Condition < int.Parse(Helper.Value.Trim()))
                    {
                        i = CurrLine;
                    }
                    else
                    {
                        i = End_Line_Finder(Lines, CurrLine);
                    }
                }
                if (int.TryParse(Condition_Parts[2].Trim(), out Value_In_Condition))
                {
                    if (int.Parse(Helper.Value.Trim()) < Value_In_Condition)
                    {
                        i = CurrLine;
                    }
                    else
                    {
                        i = End_Line_Finder(Lines, CurrLine);
                    }
                }
            }


            if (Condition_Parts[1] == ">")
            {
                Helper = Variables.Where(x => x.Name == Condition_Parts[0] || x.Name == Condition_Parts[2]).First();
                int Value_In_Condition;
                if (int.TryParse(Condition_Parts[0].Trim(), out Value_In_Condition))
                {
                    if (Value_In_Condition <= int.Parse(Helper.Value.Trim()))
                    {
                        i = CurrLine;
                    }
                    else
                    {
                        i = End_Line_Finder(Lines, CurrLine);
                    }
                }
                if (int.TryParse(Condition_Parts[2].Trim(), out Value_In_Condition))
                {
                    if (int.Parse(Helper.Value.Trim()) <= Value_In_Condition)
                    {
                        i = CurrLine;
                    }
                    else
                    {
                        i = End_Line_Finder(Lines, CurrLine);
                    }
                }
            }


            if (Condition_Parts[1] == "<")
            {
                Helper = Variables.Where(x => x.Name == Condition_Parts[0] || x.Name == Condition_Parts[2]).First();
                int Value_In_Condition;
                if (int.TryParse(Condition_Parts[0].Trim(), out Value_In_Condition))
                {
                    if (Value_In_Condition >= int.Parse(Helper.Value.Trim()))
                    {
                        i = CurrLine;
                    }
                    else
                    {
                        i = End_Line_Finder(Lines, CurrLine);
                    }
                }
                if (int.TryParse(Condition_Parts[2].Trim(), out Value_In_Condition))
                {
                    if (int.Parse(Helper.Value.Trim()) >= Value_In_Condition)
                    {
                        i = CurrLine;
                    }
                    else
                    {
                        i = End_Line_Finder(Lines, CurrLine);
                    }
                }
            }
            return i;
        }

        //Find the end of a program unit
        static int End_Line_Finder(string[] Lines, int Start_Line)
        {
            int i = Start_Line;
            int opener = 0, closer = 0;
            while (opener != closer || (opener == 0 && closer == 0))
            {
                if (First_Word_Finder(Lines[i]) == "{")
                {
                    opener++;
                }
                if (First_Word_Finder(Lines[i]) == "}")
                {
                    closer++;
                }
                i++;
            }
            i--;
            return i;
        }

        //Reading the source and proccess it
        static void ReadLines(string[] Lines)
        {
            Stack Conditions_Stack = new Stack();

            for (int i = 0; i < Lines.Length; i++)
            {
                string Line = Lines[i];
                if (First_Word_Finder(Line) == "function" && !Line.Contains("main"))
                {
                    Functions.Add(new Function_Class(Line));
                    KeyWords.Add(Functions[Functions.Count - 1].Name);
                }
                if (First_Word_Finder(Line) == "let")
                {
                    Variables.Add(new Variable(Line));
                    KeyWords.Add(Variables[Variables.Count - 1].Name);
                }
                if (First_Word_Finder(Line) == "write")
                {
                    Write_Function(Line);
                }

                foreach (var item in Variables)
                {
                    if (item.Name == First_Word_Finder(Line))
                    {
                        Operation(item, Line);
                    }
                }

                if (First_Word_Finder(Line) == "if")
                {
                    Conditions_Stack.Push(Line);
                    //LegutobbiElagazas = sor;
                    i = Condition_Function(Lines, i);
                }
                if (First_Word_Finder(Line) == "else")
                {
                    i = Else_Condition(Lines, Conditions_Stack.Pop().ToString(), i);
                }

                if (First_Word_Finder(Line) == "for")
                {
                    i = Loop_Function(Lines, i);
                }

                if (First_Word_Finder(Line) == "read")
                {
                    Read_Function(Line);
                }

            }
        }

        //Handling loops
        static int Loop_Function(string[] Lines, int CurrLine)
        {
            int back = 0;
            int Growth_Rate = 1;
            string Line = Lines[CurrLine];
            if (Line.Contains(','))
            {
                string[] Sides = Line.Split(',');

                Sides[1] = Sides[1].Remove(Sides.Length, 1);
                Growth_Rate = int.Parse(Sides[1].Trim());
            }
            int FirstPart = 0, SecondPart = 0;
            string[] Parts = Line.Split(' ');
            string Loop_Variable = "";

            if (Line.Contains("let"))
            {
                var VariableWithTheSameName = Variables.Where(x => x.Name == Parts[2]);
                if (VariableWithTheSameName.Count() != 0)
                {
                    VariableWithTheSameName.First().Value = Parts[4];
                    Loop_Variable = VariableWithTheSameName.First().Name;
                }
                else
                {
                    Loop_Variable = Parts[2];
                    string item = "let " + Parts[2] + " =" + Parts[4];
                    Variables.Add(new Variable(item));
                }

                FirstPart = int.Parse(Parts[4]);
                Parts[6] = Parts[6].Remove(Parts[6].Length - 1, 1);
                SecondPart = int.Parse(Parts[6].Trim());
            }
            else
            {

                Parts[1] = Parts[1].Remove(0, 1);
                string item = "let i =" + Parts[1];
                Loop_Variable = "i";
                Variables.Add(new Variable(item));
                FirstPart = int.Parse(Parts[1]);
                Parts[3] = Parts[3].Remove(Parts[3].Length - 1, 1);
                SecondPart = int.Parse(Parts[3].Trim());

            }

            int Lines_Count = End_Line_Finder(Lines, CurrLine) - CurrLine;

            string[] Need_To_Read = new string[Lines_Count];
            int Helper = CurrLine + 1;
            for (int i = 0; i < Lines_Count; i++)
            {
                Need_To_Read[i] = Lines[Helper];
                Helper++;
            }

            ReadLines(Need_To_Read);
            if (FirstPart < SecondPart)
            {
                for (int i = FirstPart; i < SecondPart; i += Growth_Rate)
                {
                    Variable Loop_Variable2 = Variables.Where(x => x.Name == Loop_Variable).First();
                    Loop_Variable2.Value = (int.Parse(Loop_Variable2.Value) + Growth_Rate).ToString();
                    ReadLines(Need_To_Read);
                }
            }
            if (FirstPart > SecondPart)
            {
                Console.WriteLine(FirstPart + " " + SecondPart);
                for (int i = FirstPart; i >= SecondPart; i -= Growth_Rate)
                {
                    Variable Loop_Variable2 = Variables.Where(x => x.Name == Loop_Variable).First();
                    Loop_Variable2.Value = (int.Parse(Loop_Variable2.Value) - Growth_Rate).ToString();
                    ReadLines(Need_To_Read);
                }
            }

            back = End_Line_Finder(Lines, CurrLine);
            return back;
        }

        //Handling inputs
        static void Read_Function(string Line)
        {
            string[] Splited_Array = Line.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            Splited_Array[1] = Splited_Array[1].Remove(0, 1);
            Splited_Array[1] = Splited_Array[1].Remove(Splited_Array[1].Length - 1, 1);
            string input = Console.ReadLine();

            Variable helper = Variables.Where(x => x.Name == Splited_Array[1].Trim()).First();
            helper.Value = input;
        }

        //Find the first word of the line
        static string First_Word_Finder(string Line)
        {
            string word = "";
            if (Line.Length >= 1)
            {

                string[] words = Line.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                word = words[0].Trim();
            }
            return word;
        }


        static void Main(string[] args)
        {
            string source = "";
            Console.Write("Please provide the file path:");

            source = Console.ReadLine();
            string Text = File.ReadAllText(source);
            if (Text.Contains("main"))
            {

                KeyWords.Add("let");
                KeyWords.Add("for");
                KeyWords.Add("=>");
                KeyWords.Add("write");
                KeyWords.Add("if");
                KeyWords.Add("else");

                Operators.Add("==");
                Operators.Add("<=");
                Operators.Add(">=");
                Operators.Add("<");
                Operators.Add(">");
                Operators.Add("!=");

                string[] Lines = File.ReadAllLines(source);
                ReadLines(Lines);
            }
            else
                Console.WriteLine("Program does not have a main function");
            Console.ReadKey();
        }

    }
}
